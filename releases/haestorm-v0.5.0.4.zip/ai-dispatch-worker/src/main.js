import http from 'node:http';
import crypto from 'node:crypto';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { Ledger, EventQueue, radioText } from './core.js';
import { LocalSpeechProvider } from './provider.js';
import { Imbe } from './codecs.js';
import { RadioBridge } from './radio.js';
import { Understanding } from './understanding.js';

const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const WORKER_BUILD='v0.5.0.3-radio-text-fix';
const token=process.env.AI_DISPATCH_BRIDGE_TOKEN||'';
if(token.length<32)throw new Error('missing_private_bridge_token');
const events=new EventQueue();
const ledger=new Ledger(path.join(root,'state','usage.json'),Number(process.env.AI_DISPATCH_MONTHLY_BUDGET||20));
const understanding=new Understanding({apiKey:process.env.OPENAI_API_KEY||'',ledger});
let radio=null,provider=null,ready=false,reason='credentials_required';
if(process.env.AI_DISPATCH_RADIO_NAC) {
  try {
    provider=new LocalSpeechProvider({sttMode:'local',localSttUrl:process.env.AI_DISPATCH_LOCAL_STT_URL||'http://127.0.0.1:8790',localKokoroUrl:process.env.AI_DISPATCH_LOCAL_KOKORO_URL||'http://127.0.0.1:8792',localKokoroVoice:process.env.AI_DISPATCH_LOCAL_KOKORO_VOICE||'af_sarah',localTtsUrl:process.env.AI_DISPATCH_LOCAL_TTS_URL||'http://127.0.0.1:8791',localTtsVoice:process.env.AI_DISPATCH_LOCAL_TTS_VOICE||'en_US-amy-medium'});
    await provider.verify();
    const imbe=await Imbe.load(process.env.AI_DISPATCH_IMBE_PATH||'');
    radio=new RadioBridge({url:process.env.AI_DISPATCH_RADIO_URL||'http://127.0.0.1:7778',nac:process.env.AI_DISPATCH_RADIO_NAC,provider,imbe,ledger,events});
    ready=true;reason='ready';
  } catch(error) {console.warn(`[AI radio worker] startup failed: ${error?.message||'unknown'}`);reason='provider_or_codec_configuration_failed';}
}
function authenticated(req) {
  const supplied=Buffer.from(req.headers.authorization||'');const expected=Buffer.from(`Bearer ${token}`);
  return supplied.length===expected.length&&crypto.timingSafeEqual(supplied,expected);
}
async function body(req) {
  const chunks=[];let size=0;
  for await(const chunk of req){size+=chunk.length;if(size>131072)throw new Error('request_too_large');chunks.push(chunk);}
  return JSON.parse(Buffer.concat(chunks).toString('utf8'));
}
const server=http.createServer(async(req,res)=>{
  res.setHeader('Content-Type','application/json');res.setHeader('Cache-Control','no-store');
  const send=(code,data)=>{res.writeHead(code);res.end(JSON.stringify(data));};
  if(!authenticated(req)){send(401,{ok:false});return;}
  try {
    if(req.method==='GET'&&req.url==='/health'){const policy=radio?.currentPolicy();send(200,{ok:true,workerBuild:WORKER_BUILD,ready,reason,understandingConfigured:!!process.env.OPENAI_API_KEY,radioConnected:radio?.connected||false,voiceEnabled:policy?.enabled===true,eligibleUnits:policy?.enabled ? policy.units?.length||0 : 0,lastDeliveryError:radio?.lastDeliveryError||null,lastDeliveryStage:radio?.lastDeliveryStage||null,lastDeliverySuccessAt:radio?.lastDeliverySuccessAt||null,lastDeliveryFailureAt:radio?.lastDeliveryFailureAt||null,lastSttError:radio?.lastSttError||null,lastSttStage:radio?.lastSttStage||null,lastSttAt:radio?.lastSttAt||null,lastSttAudio:radio?.lastSttAudio||null,radioFilter:process.env.AI_DISPATCH_RADIO_FILTER==='off'?'off':'on',liveCodec:radio?.liveCodecSummary?.()||'unknown',voiceMode:provider?.voiceMode||null,voiceName:provider?.voiceName||null,sttProvider:provider?.sttProvider||null,ttsProvider:provider?.ttsProvider||null,estimatedUsageUSD:ledger.spent,bargeInCount:radio?.bargeInCount||0,lastBargeInAt:radio?.lastBargeInAt||null,packetCacheHits:radio?.packetCacheHits||0,packetCacheMisses:radio?.packetCacheMisses||0,lastPrepareMs:radio?.lastPrepareMs||null,pttDebug:radio?.pttDebug||null,responseDebug:radio?.responseDebug||null});return;}
    if(req.method==='POST'&&req.url==='/interpret'){const value=await body(req);send(200,{ok:true,result:await understanding.interpret(value)});return;}
    if(req.method==='POST'&&req.url==='/policy'){const policy=await body(req);radio?.setPolicy(policy);send(200,{ok:true,ready});return;}
    if(req.method==='GET'&&req.url==='/events'){send(200,{ok:true,events:events.peek()});return;}
    if(req.method==='POST'&&req.url==='/ack'){const value=await body(req);if(!Array.isArray(value.ids)||value.ids.length>8)throw new Error('invalid_ack');events.ack(value.ids);send(200,{ok:true});return;}
    if(req.method==='POST'&&req.url==='/speak') {
      const value=await body(req);if(typeof value.text!=='string'||value.text.length>600)throw new Error('invalid_speech');
      const configuredSpeed=Number(process.env.AI_DISPATCH_VOICE_SPEED || value.speed || 1.18);
      if(!Number.isFinite(configuredSpeed)||configuredSpeed<0.7||configuredSpeed>1.28)throw new Error('invalid_voice_speed');
      const allowedVoices=new Set(['af_sarah','af_bella','af_alloy','af_heart','af_nicole']);
      if(value.voice!=null&&!allowedVoices.has(String(value.voice)))throw new Error('invalid_voice');
      value.speed=configuredSpeed;
      value.text=radioText(value.text);
      if(radio)radio.responseDebug.lastSpeakRequest={at:new Date().toISOString(),id:String(value.id||''),channel:Number(value.channel),text:String(value.text||'').slice(0,300),voice:value.voice||null,speed:value.speed,emergency:value.emergency===true};
      const accepted=radio?.enqueue(value)||false;
      if(radio)radio.responseDebug.lastSpeakAccepted={at:new Date().toISOString(),id:String(value.id||''),accepted};
      console.log(`[AI response debug] SPEAK REQUEST id=${String(value.id||'')} channel=${Number(value.channel)} accepted=${accepted} text=${JSON.stringify(String(value.text||'').slice(0,220))}`);
      send(200,{ok:accepted,queued:accepted});return;
    }
    if(req.method==='POST'&&req.url==='/voice-preview') {
      const value=await body(req);
      const aliases={sarah:'af_sarah',bella:'af_bella',alloy:'af_alloy',heart:'af_heart',nicole:'af_nicole'};
      const requested=String(value.voice||'sarah').toLowerCase();
      const voice=aliases[requested]||requested;
      if(!Object.values(aliases).includes(voice))throw new Error('invalid_voice');
      const channel=Number(value.channel||100);
      if(!Number.isFinite(channel)||channel<=0)throw new Error('invalid_channel');
      const text=typeof value.text==='string'&&value.text.trim()?value.text.trim():'Zero Henry Two, go ahead. Zero Henry Two, copy. Plate when ready. All units hold the air. Shots fired.';
      if(text.length>400)throw new Error('invalid_speech');
      const id=`preview:${voice}:${Date.now()}`;
      const ok=radio?.enqueue({id,channel,text:radioText(text),speed:1.17,voice,emergency:false,priority:70})||false;
      send(200,{ok,queued:ok,voice,channel});return;
    }
    if(req.method==='POST'&&req.url==='/cancel'){radio?.cancel();events.clear();send(200,{ok:true});return;}
    if(req.method==='POST'&&req.url==='/shutdown'){send(200,{ok:true});setImmediate(close);return;}
    send(404,{ok:false});
  } catch {send(400,{ok:false,error:'request_rejected'});}
});
server.requestTimeout=5000;server.headersTimeout=5000;
server.listen(Number(process.env.AI_DISPATCH_WORKER_PORT||8789),'127.0.0.1',()=>console.log(`[AI radio worker] ${reason}; listening on loopback only`));
const reconnect=setInterval(()=>{if(radio?.policy?.enabled&&!radio.connected)radio.connect().catch(()=>radio.scheduleReconnect());radio?.syncChannels();},2000);
const heartbeat=setInterval(()=>{if(radio?.connected)radio.socket.emit('heartbeat',Date.now());},5000);
function close(){clearInterval(reconnect);clearInterval(heartbeat);radio?.close();server.close();}
process.on('SIGINT',close);process.on('SIGTERM',close);
