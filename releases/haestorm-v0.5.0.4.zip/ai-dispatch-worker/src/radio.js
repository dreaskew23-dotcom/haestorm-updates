import { io } from 'socket.io-client';
import crypto from 'node:crypto';
import { authorizedPacket, frequency, validBase64 } from './core.js';
import { downsample24to8, decodeOpusContainer, normalizeSttPcm, encodeOpusContainer, dispatchRadioFilter, analyzePcm16 } from './codecs.js';

export class RadioBridge {
  constructor({ url, nac, provider, imbe, ledger, events, socketFactory = io, fetchImpl = fetch }) {
    const origin = new URL(url);
    if (!['http:','https:'].includes(origin.protocol) || (origin.protocol === 'http:' && !['localhost','127.0.0.1','[::1]'].includes(origin.hostname))) throw new Error('radio_requires_https_or_loopback');
    this.url=origin.origin; this.nac=nac; this.provider=provider; this.imbe=imbe; this.ledger=ledger; this.events=events; this.socketFactory=socketFactory; this.fetch=fetchImpl;
    this.policy={enabled:false,units:[],channels:[]}; this.lastSttError=null; this.lastSttStage=null; this.lastSttAt=null; this.lastSttAudio=null; this.pttDebug={talkingEvents:0,pttStarts:0,pttEnds:0,voicePackets:0,authorizedVoicePackets:0,rejectedTalking:0,rejectedVoice:0,lastTalking:null,lastPttStart:null,lastPttEnd:null,lastVoice:null,lastFinish:null,lastTranscript:null};
    this.responseDebug={
      queued:0,
      delivered:0,
      failed:0,
      lastSpeakRequest:null,
      lastSpeakAccepted:null,
      lastQueued:null,
      lastTtsStart:null,
      lastTtsDone:null,
      lastCodecDone:null,
      lastTransmitStart:null,
      lastDelivered:null,
      lastFailure:null
    }; this.lastDeliveryError=null; this.lastDeliveryStage=null; this.lastDeliverySuccessAt=null; this.lastDeliveryFailureAt=null; this.sessions=new Map(); this.queue=[]; this.talkers=new Map(); this.connected=false; this.running=false; this.stopped=false; this.processing=0; this.epoch=0; this.subscribed=new Set(); this.processingControllers=new Set(); this.channelEncodings=new Map(); this.noticeThrottle=new Map(); this.deliveryFailureThrottle=new Map(); this.reconnectTimer=null; this.reconnectAttempts=0; this.currentMessage=null; this.bargeInCount=0; this.lastBargeInAt=null; this.lastChannelClearAt=new Map(); this.packetCache=new Map(); this.packetCacheBytes=0; this.packetCacheHits=0; this.packetCacheMisses=0; this.lastPrepareMs=null;
  }

  packetCacheGet(key) {
    const hit=this.packetCache.get(key);
    if(!hit){this.packetCacheMisses++;return null;}
    this.packetCache.delete(key);this.packetCache.set(key,hit);this.packetCacheHits++;
    return hit.packets;
  }
  packetCacheSet(key,packets) {
    if(!Array.isArray(packets)||!packets.length)return;
    const bytes=packets.reduce((n,p)=>n+(Buffer.isBuffer(p?.data)?p.data.length:0),0);
    if(!bytes||bytes>6*1024*1024)return;
    if(this.packetCache.has(key)){this.packetCacheBytes-=this.packetCache.get(key).bytes;this.packetCache.delete(key);}
    this.packetCache.set(key,{packets,bytes});this.packetCacheBytes+=bytes;
    while(this.packetCache.size>96||this.packetCacheBytes>48*1024*1024){const first=this.packetCache.keys().next().value;if(first===undefined)break;const old=this.packetCache.get(first);this.packetCache.delete(first);this.packetCacheBytes-=old.bytes;}
  }

  async connect() {
    if(this.stopped||this.connecting||this.connected)return;
    this.connecting=true;
    try {
      const response=await this.fetch(`${this.url}/radio/dispatch/auth`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({nacId:this.nac,callsign:'AI Dispatch'}),signal:AbortSignal.timeout(5000),redirect:'error'});
      if(!response.ok)throw new Error('radio_authentication_failed');
      const auth=await response.json();
      if(auth.success!==true||typeof auth.authToken!=='string'||typeof auth.sessionId!=='string')throw new Error('radio_authentication_failed');
      const socket=this.socketFactory(this.url,{auth:{authToken:auth.authToken,sessionId:auth.sessionId,serverId:-91214},transports:['websocket'],reconnection:false,timeout:5000});
      this.socket=socket;
      socket.on('connect',()=>{this.connected=true;this.reconnectAttempts=0;if(this.reconnectTimer){clearTimeout(this.reconnectTimer);this.reconnectTimer=null;}socket.emit('setDispatchSession',auth.sessionId);socket.emit('updateUserInfo',{name:'AI Dispatch',nacId:this.nac});this.syncChannels();this.drain();});
      socket.on('disconnect',()=>{this.connected=false;this.subscribed.clear();this.talkers.clear();this.cancel(false);this.scheduleReconnect();});
      socket.on('connect_error',()=>{this.connected=false;socket.disconnect();this.scheduleReconnect();});
      socket.on('talkingState',packet=>this.talking(packet));
      socket.on('voice',packet=>this.voice(packet));
      socket.on('ptt:denied',()=>{this.pttDenied=true;});
      socket.on('channelState',p=>{if(!p||!Array.isArray(p.activeTalkers))return;try{this.talkers.set(frequency(p.frequency),new Set(p.activeTalkers.map(x=>Number(typeof x==='object'?x.serverId:x))));}catch{}});
    } finally {this.connecting=false;}
  }
  setPolicy(policy) {
    if(!policy||typeof policy.enabled!=='boolean'||!Array.isArray(policy.units)||!Array.isArray(policy.channels))throw new Error('invalid_policy');
    if(!policy.enabled||policy.generation!==this.policy.generation) this.cancel();
    this.policy=policy;this.policyTime=Date.now();this.syncChannels();
  }
  currentPolicy() {return Date.now()-(this.policyTime||0)<5000?this.policy:{enabled:false};}
  liveCodecSummary() {
    const now=Date.now(), modes=new Set();
    for(const value of this.channelEncodings.values())if(now-value.seen<30000)modes.add(value.encoding);
    return modes.size?[...modes].sort().join('+'):'unknown';
  }
  scheduleReconnect() {
    if(this.stopped||this.connected||this.connecting||!this.policy?.enabled||this.reconnectTimer)return;
    const delay=Math.min(10000,1000*Math.pow(2,Math.min(this.reconnectAttempts++,3)));
    this.reconnectTimer=setTimeout(()=>{this.reconnectTimer=null;this.connect().catch(()=>this.scheduleReconnect());},delay);
  }
  syncChannels() {
    if(!this.connected)return;
    const desired=new Set(this.currentPolicy().enabled?this.policy.channels.map(c=>frequency(c.frequency)):[]);
    for(const ch of this.subscribed) if(!desired.has(ch)){this.socket.emit('removeListeningChannel',ch);this.subscribed.delete(ch);}
    for(const ch of desired) if(!this.subscribed.has(ch)){this.socket.emit('addListeningChannel',ch);this.subscribed.add(ch);}
  }
  cancel(clearEvents=true) {
    this.epoch++;this.controller?.abort();this.queue=[];
    for(const controller of this.processingControllers)controller.abort();
    for(const session of this.sessions.values()){clearTimeout(session.timer);clearTimeout(session.finishTimer);this.imbe?.close(session.id);}
    this.sessions.clear();if(clearEvents)this.events.clear();
    if(this.connected) {this.socket.emit('setTalking',{state:false});this.socket.emit('setSpeakerChannel',-1);}
  }
  talking(packet) {
    this.pttDebug.talkingEvents++;
    if(!packet||!Number.isInteger(packet.serverId)||packet.serverId<=0){this.pttDebug.rejectedTalking++;return;}
    let ch;try{ch=frequency(packet.frequency);}catch{this.pttDebug.rejectedTalking++;return;}
    this.pttDebug.lastTalking={at:new Date().toISOString(),source:packet.serverId,channel:Number(ch),state:packet.state===true};
    const talkers=this.talkers.get(ch)||new Set();this.talkers.set(ch,talkers);
    if(packet.state===true) {
      talkers.add(packet.serverId);
      for(const session of this.sessions.values())if(session.channel===ch&&session.source!==packet.serverId)session.overlap=true;
      const u=authorizedPacket(this.currentPolicy(),packet);if(!u){this.pttDebug.rejectedTalking++;console.log(`[AI PTT debug] PTT START rejected source=${packet.serverId} channel=${ch} policyEnabled=${this.currentPolicy().enabled===true}`);return;}
      this.pttDebug.pttStarts++;this.pttDebug.lastPttStart={at:new Date().toISOString(),source:packet.serverId,channel:Number(ch),session:u.session};
      console.log(`[AI PTT debug] PTT START source=${packet.serverId} channel=${ch} session=${u.session}`);
      // Real-radio barge in: a valid officer PTT always wins over synthetic dispatch audio.
      // Cut AI transmission immediately; the officer's voice continues untouched.
      if(this.controller && this.currentMessage && this.currentMessage.channel===ch){
        this.bargeInCount++; this.lastBargeInAt=new Date().toISOString();
        this.controller.abort();
        try{this.socket.emit('setTalking',{state:false,frequency:ch});this.socket.emit('setSpeakerChannel',-1);}catch{}
        console.log(`[AI radio worker] officer barge-in source=${packet.serverId} channel=${ch}; dispatch yielded`);
      }
      const key=`${packet.serverId}:${ch}`;if(this.sessions.has(key))return;
      const session={id:crypto.randomUUID(),source:packet.serverId,channel:ch,unitSession:u.session,started:Date.now(),packets:[],bytes:0,samples:0,overlap:talkers.size>1,epoch:this.epoch};
      session.timer=setTimeout(()=>{session.invalid=true;this.finish(key).catch(()=>{});},15000);
      this.sessions.set(key,session);
    } else if(packet.state===false) {
      talkers.delete(packet.serverId);
      if(talkers.size===0)this.lastChannelClearAt.set(ch,Date.now());
      const key=`${packet.serverId}:${ch}`,session=this.sessions.get(key);
      if(session){this.pttDebug.pttEnds++;this.pttDebug.lastPttEnd={at:new Date().toISOString(),source:packet.serverId,channel:Number(ch),packets:session.packets.length,bytes:session.bytes,encoding:session.encoding||null};console.log(`[AI PTT debug] PTT END source=${packet.serverId} channel=${ch} packets=${session.packets.length} bytes=${session.bytes} encoding=${session.encoding||'unknown'}`);}
      if(session&&!session.finishTimer)session.finishTimer=setTimeout(()=>this.finish(key).catch(()=>{}),180); // short tail for final codec packet; tuned for dispatch latency
    }
  }
  voice(packet) {
    this.pttDebug.voicePackets++;
    const u=authorizedPacket(this.currentPolicy(),packet);if(!u){this.pttDebug.rejectedVoice++;if(this.pttDebug.rejectedVoice<=5||this.pttDebug.rejectedVoice%50===0)console.log(`[AI PTT debug] VOICE rejected source=${packet?.serverId??'unknown'} channel=${packet?.frequency??'unknown'}`);return;}
    this.pttDebug.authorizedVoicePackets++;
    const key=`${packet.serverId}:${frequency(packet.frequency)}`,session=this.sessions.get(key);
    if(!session||session.unitSession!==u.session)return;
    try {
      const bytes=validBase64(packet.data,65536),encoding=packet.encoding||'opus';
      this.pttDebug.lastVoice={at:new Date().toISOString(),source:packet.serverId,channel:Number(frequency(packet.frequency)),encoding,packetBytes:bytes.length,totalAuthorizedPackets:this.pttDebug.authorizedVoicePackets};
      this.channelEncodings.set(frequency(packet.frequency),{encoding,seen:Date.now()});
      if(!['opus','imbe'].includes(encoding)||(session.encoding&&session.encoding!==encoding))throw new Error('unsupported_encoding');
      session.encoding=encoding;session.bytes+=bytes.length;
      if(session.bytes>2*1024*1024||session.packets.length>=160||Date.now()-session.started>15500)throw new Error('transmission_too_long');
      if(encoding==='imbe') {const pcm=this.imbe.decode(session.id,bytes);session.samples+=pcm.length/2;if(session.samples>8000*15)throw new Error('transmission_too_long');session.packets.push(pcm);}
      else session.packets.push(bytes);
    } catch {session.invalid=true;}
  }
  async finish(key) {
    const s=this.sessions.get(key);if(!s)return;this.sessions.delete(key);clearTimeout(s.timer);clearTimeout(s.finishTimer);this.imbe?.close(s.id);
    this.pttDebug.lastFinish={at:new Date().toISOString(),source:s.source,channel:Number(s.channel),packets:s.packets.length,bytes:s.bytes,encoding:s.encoding||null,invalid:s.invalid===true,overlap:s.overlap===true};
    console.log(`[AI PTT debug] FINISH source=${s.source} channel=${s.channel} packets=${s.packets.length} bytes=${s.bytes} encoding=${s.encoding||'unknown'} invalid=${s.invalid===true} overlap=${s.overlap===true}`);
    const u=authorizedPacket(this.currentPolicy(),{serverId:s.source,frequency:s.channel});
    if(!u||u.session!==s.unitSession||s.epoch!==this.epoch)return;
    if(s.overlap) {this.events.add({kind:'transcript',source:s.source,channel:Number(s.channel),text:'Dispatch',confidence:null,session:s.unitSession,overlap:true,id:s.id});return;}
    if(s.invalid||!s.packets.length||this.processing>=4){this.notice(s,'Radio audio could not be processed. Repeat or use typed dispatch.');return;}
    this.processing++;
    const abort=new AbortController();const epoch=this.epoch;this.processingControllers.add(abort);
    try {
      this.lastSttStage='decode';
      let pcm,sampleRate,decodeMode=s.encoding==='imbe'?'imbe':'unknown',audioStats,failedPackets=0;
      if(s.encoding==='imbe') {
        pcm=Buffer.concat(s.packets);sampleRate=8000;audioStats=analyzePcm16(pcm,sampleRate);
        if(audioStats.durationMs<220)throw new Error('imbe_audio_too_short');
        if(audioStats.rms<18||audioStats.peak<90||audioStats.nonZeroRatio<0.002)throw new Error('imbe_audio_silent');
      } else {
        const decoded=await decodeOpusContainer(s.packets,Date.now()-s.started);
        pcm=decoded.pcm;sampleRate=decoded.sampleRate;decodeMode=decoded.mode;audioStats=decoded.stats;failedPackets=decoded.failedPackets;
      }
      const sourceSampleRate=sampleRate;
      const normalized=await normalizeSttPcm(pcm,sampleRate);
      pcm=normalized.pcm;sampleRate=normalized.sampleRate;audioStats=normalized.stats;
      this.lastSttAudio={encoding:s.encoding,sampleRate,durationMs:audioStats.durationMs,rms:audioStats.rms,peak:audioStats.peak,decodeMode,sourceSampleRate,providerFormat:'pcm_16000',packets:s.packets.length,failedPackets};
      if(pcm.length>sampleRate*2*15||!this.currentPolicy().enabled||epoch!==this.epoch||Date.now()-s.started>30000)return;
      // Reserve up to one minute at the configured list rate; keep reservation
      // on uncertain failures. This is an estimated cap, not provider billing.
      if((this.provider.sttCostPerMinute||0)>0&&!this.ledger.reserve(`stt:${s.id}`,this.provider.sttCostPerMinute))return;
      this.lastSttStage='provider';
      console.log(`[AI PTT debug] STT FORWARD source=${s.source} channel=${s.channel} durationMs=${Math.round(audioStats.durationMs)} rms=${Math.round(audioStats.rms)} peak=${Math.round(audioStats.peak)} packets=${s.packets.length}`);
      let result;
      for(let attempt=1;attempt<=2;attempt++) {
        const timer=setTimeout(()=>abort.abort(),12000);
        try { result=await this.provider.transcribe(pcm,sampleRate,abort.signal); break; }
        catch(error) {
          const retryable=/^(stt_connection_failed|stt_closed_without_transcript|stt_timeout|stt_provider_rejected)$/.test(error?.message||'');
          if(attempt>=2||!retryable||abort.signal.aborted)throw error;
          console.warn(`[AI radio worker] stt retry 1/1: ${error.message}`);
          await new Promise(r=>setTimeout(r,220));
        } finally { clearTimeout(timer); }
      }
      this.lastSttError=null;this.lastSttStage=null;this.lastSttAt=new Date().toISOString();
      this.pttDebug.lastTranscript={at:this.lastSttAt,source:s.source,channel:Number(s.channel),text:String(result.text||'').slice(0,240),confidence:result.confidence??null};
      console.log(`[AI PTT debug] STT RESULT source=${s.source} channel=${s.channel} text=${JSON.stringify(String(result.text||'').slice(0,240))} confidence=${result.confidence??'unknown'}`);
      const latest=authorizedPacket(this.currentPolicy(),{serverId:s.source,frequency:s.channel});
      if(epoch===this.epoch&&latest?.session===s.unitSession)this.events.add({kind:'transcript',source:s.source,channel:Number(s.channel),text:result.text,confidence:result.confidence,session:s.unitSession,overlap:false,id:s.id});
    } catch(error) {
      if(epoch===this.epoch){
        const safe=/^(opus_decode_failed|opus_audio_too_short|opus_audio_silent|imbe_audio_too_short|imbe_audio_silent|invalid_pcm|invalid_pcm_duration|stt_connection_failed|stt_closed_without_transcript|stt_timeout|stt_provider_rejected|stt_invalid_response|stt_invalid_transcript|stt_audio_too_short|stt_audio_silent|invalid_pcm_rate|stt_provider_rate_limited|stt_provider_quota|stt_provider_auth|provider_zero_retention_not_available|local_stt_unavailable|local_stt_not_ready|local_stt_rejected_audio|local_stt_failed|local_stt_invalid_response|operation_cancelled|codec_timeout|codec_process_failed|decoded_audio_too_large|transmission_too_long)$/.test(error?.message||'')?error.message:'stt_failed';
        this.lastSttError=safe;this.lastSttAt=new Date().toISOString();
        console.warn(`[AI radio worker] stt failed stage=${this.lastSttStage||'unknown'} reason=${safe} encoding=${s.encoding||'unknown'} packets=${s.packets.length}`);
        this.notice(s,'Speech recognition temporarily unavailable. Repeat your traffic or use typed dispatch.');
      }
    }
    finally {this.processing--;this.processingControllers.delete(abort);}
  }
  notice(s,message){
    const key=`${s.source}:${s.channel}:${message}`;const now=Date.now();
    if(now-(this.noticeThrottle.get(key)||0)<5000)return;this.noticeThrottle.set(key,now);
    try{this.events.add({kind:'notice',source:s.source,channel:Number(s.channel),session:s.unitSession,message});}catch{}
  }
  enqueue(message) {
    const policy=this.currentPolicy();
    if(!policy.enabled||!this.connected||!this.provider||this.queue.length>=32||typeof message.text!=='string'||message.text.length>600||typeof message.id!=='string')return false;
    const ch=frequency(message.channel),configured=policy.channels.find(c=>frequency(c.frequency)===ch);
    if(!configured||(!policy.routine&&message.emergency!==true))return false;
    const text=String(message.text||'').toLowerCase();
    let priority=Number(message.priority);
    if(!Number.isFinite(priority)){
      if(/officer needs help|officer down|shots fired|panic|emergency traffic/.test(text))priority=100;
      else if(message.emergency&&/pursuit|foot pursuit|lost visual|bail|crash|northbound|southbound|eastbound|westbound/.test(text))priority=90;
      else if(message.emergency)priority=80;
      else if(/backup|additional unit|start another/.test(text))priority=65;
      else if(/plate|returns|registered|warrant|record/.test(text))priority=35;
      else priority=20;
    }
    this.queue.push({...message,channel:ch,encoding:configured.encoding,epoch:this.epoch,_priority:priority});
    this.responseDebug.queued++;
    this.responseDebug.lastQueued={at:new Date().toISOString(),id:String(message.id||''),channel:ch,text:String(message.text||'').slice(0,300),priority,emergency:message.emergency===true};
    console.log(`[AI response debug] QUEUED id=${String(message.id||'')} channel=${ch} priority=${priority} emergency=${message.emergency===true}`);
    if(message.emergency&&this.controller&&!this.playingEmergency)this.controller.abort();
    this.queue.sort((a,b)=>(b._priority||0)-(a._priority||0));
    this.drain();return true;
  }
  async drain() {
    if(this.running)return;this.running=true;
    try {while(this.queue.length&&this.connected&&this.currentPolicy().enabled) {
      const message=this.queue.shift();
      if(message.epoch!==this.epoch)continue;
      const abort=new AbortController();this.controller=abort;this.currentMessage=message;this.pttDenied=false;this.playingEmergency=message.emergency===true;
      try {
        const deadline=Date.now()+15000;
        while([...this.talkers.get(message.channel)||[]].some(id=>id>0)) {
          if(Date.now()>deadline||abort.signal.aborted)throw new Error('radio_busy');
          await new Promise(r=>setTimeout(r,45));
        }
        if(!this.currentPolicy().enabled||message.epoch!==this.epoch)throw new Error('operation_cancelled');
        // v0.4.29: prepare audio immediately, then enforce only the remaining
        // real-console key-up gap. This overlaps TTS/codec work with the natural pause
        // instead of stacking the pause on top of generation latency.
        const prepareStarted=Date.now();
        let packets;
        for(let attempt=1;attempt<=2;attempt++) {
          try {
            this.deliveryStage='tts';
            this.responseDebug.lastTtsStart={at:new Date().toISOString(),id:String(message.id||''),channel:message.channel,text:String(message.text||'').slice(0,300),voice:message.voice||null};
            console.log(`[AI response debug] TTS START id=${String(message.id||'')} channel=${message.channel} provider=${this.provider?.ttsProvider||'unknown'}`);
            const requestedSpeed=Number(message.speed||1.18);
            const lowerText=String(message.text||'').toLowerCase();
            const isRecords=/\b(plate|returns|registered|license|dob|date of birth|record|warrant)\b/.test(lowerText);
            const isPursuit=/\b(pursuit|foot pursuit|northbound|southbound|eastbound|westbound|lost visual|vehicle crashed|bailing|mile marker|mph)\b/.test(lowerText);
            const isEmergency=message.emergency===true;
            const deliverySpeed=isEmergency?Math.min(1.28,Math.max(requestedSpeed,1.24)):(isPursuit?Math.min(1.27,Math.max(requestedSpeed,1.23)):(isRecords?Math.min(1.14,Math.max(requestedSpeed,1.10)):Math.min(1.24,Math.max(requestedSpeed,1.20))));
            const observed=this.channelEncodings.get(message.channel);
            const liveEncoding=observed&&Date.now()-observed.seen<30000&&['opus','imbe'].includes(observed.encoding)?observed.encoding:message.encoding;
            if(liveEncoding!==message.encoding)console.warn(`[AI radio worker] adaptive channel encoding channel=${message.channel} configured=${message.encoding} observed=${liveEncoding}`);
            const selectedVoice=typeof message.voice==='string'&&message.voice?message.voice:null;
            const cacheKey=`${liveEncoding}|${isEmergency?'E':'R'}|${selectedVoice||'default'}|${deliverySpeed.toFixed(3)}|${message.text}`;
            packets=this.packetCacheGet(cacheKey);
            if(!packets){
              const synthesized=await this.provider.synthesize(message.text,deliverySpeed,abort.signal,selectedVoice);
            this.responseDebug.lastTtsDone={at:new Date().toISOString(),id:String(message.id||''),channel:message.channel,pcmBytes:synthesized?.length||synthesized?.pcm?.length||null};
            console.log(`[AI response debug] TTS DONE id=${String(message.id||'')} channel=${message.channel}`);
              this.deliveryStage='filter';
              const pcm=await dispatchRadioFilter(synthesized, isEmergency);
              this.deliveryStage='codec';
              if(liveEncoding==='imbe') {
                const input=downsample24to8(pcm);
                try {packets=this.imbe.encode(`out:${message.id}:${attempt}`,input);}finally{this.imbe.close(`out:${message.id}:${attempt}`);}
              } else packets=await encodeOpusContainer(pcm);
              this.packetCacheSet(cacheKey,packets);
            } else this.deliveryStage='cache';
            break;
          } catch(error) {
            error.deliveryStage=error.deliveryStage||this.deliveryStage||'prepare';
            const retryable=/^(local_(?:tts|kokoro)_[a-z_]+|codec_timeout|codec_process_failed)$/.test(error?.message||'');
            if(attempt>=2||!retryable||abort.signal.aborted)throw error;
            console.warn(`[AI radio worker] ${error.deliveryStage} retry 1/1: ${error.message}`);
            await new Promise(r=>setTimeout(r,180));
          }
        }
        this.lastPrepareMs=Date.now()-prepareStarted;
        this.responseDebug.lastCodecDone={at:new Date().toISOString(),id:String(message.id||''),channel:message.channel,packets:Array.isArray(packets)?packets.length:0,prepareMs:this.lastPrepareMs};
        console.log(`[AI response debug] CODEC DONE id=${String(message.id||'')} channel=${message.channel} packets=${Array.isArray(packets)?packets.length:0} prepareMs=${this.lastPrepareMs}`);
        const cleared=this.lastChannelClearAt.get(message.channel)||0;
        const gap=message.emergency===true?42:56;
        const remain=gap-(Date.now()-cleared);
        if(cleared&&remain>0)await new Promise(r=>setTimeout(r,remain));
        if(abort.signal.aborted||message.epoch!==this.epoch)throw new Error('operation_cancelled');
        this.deliveryStage='ptt';
        this.socket.emit('setSpeakerChannel',message.channel);
        // tRadio v6.3 only accepts override after a server-recorded PTT denial.
        // AI Dispatch is already authenticated as a dispatch session, so request normal PTT here.
        // This preserves tRadio's anti-spoof/override protection for every client.
        this.socket.emit('setTalking',{state:true,frequency:message.channel,override:false});
        // Brief key-up lead so the first syllable is not clipped, like a real console.
        await new Promise(r=>setTimeout(r,message.emergency===true?32:36));
        this.deliveryStage='transmit';
        this.responseDebug.lastTransmitStart={at:new Date().toISOString(),id:String(message.id||''),channel:message.channel,packets:Array.isArray(packets)?packets.length:0};
        console.log(`[AI response debug] TX START id=${String(message.id||'')} channel=${message.channel} packets=${Array.isArray(packets)?packets.length:0}`);
        for(const packet of packets) {
          if(this.pttDenied||abort.signal.aborted||!this.connected||!this.currentPolicy().enabled||message.epoch!==this.epoch)throw new Error('playback_cancelled');
          this.socket.emit('voice',{data:packet.data,encoding:packet.encoding,frequency:message.channel});
          await new Promise(r=>setTimeout(r,packet.durationMs));
        }
        this.lastDeliveryError=null; this.lastDeliveryStage=null; this.lastDeliverySuccessAt=new Date().toISOString();
        this.responseDebug.delivered++;
        this.responseDebug.lastDelivered={at:this.lastDeliverySuccessAt,id:String(message.id||''),channel:message.channel,packets:Array.isArray(packets)?packets.length:0,text:String(message.text||'').slice(0,300)};
        console.log(`[AI response debug] DELIVERED id=${String(message.id||'')} channel=${message.channel} packets=${Array.isArray(packets)?packets.length:0}`);
        console.log(`[AI radio worker] delivered id=${message.id} channel=${message.channel} stage=complete prepareMs=${this.lastPrepareMs} cacheHits=${this.packetCacheHits}`);
      } catch (error) {
        if (!abort.signal.aborted && message.epoch === this.epoch) {
          const safe = /^(local_(?:tts|kokoro)_[a-z_]+|radio_busy|playback_cancelled|codec_timeout|codec_process_failed|invalid_pcm_frame|imbe_codec_abort|monthly_budget_reached)$/.test(error?.message || '') ? error.message : 'speech_or_codec_failed';
          const stage=error?.deliveryStage||this.deliveryStage||'unknown';
          this.lastDeliveryError = safe; this.lastDeliveryStage=stage; this.lastDeliveryFailureAt=new Date().toISOString();
          this.responseDebug.failed++;
          this.responseDebug.lastFailure={at:this.lastDeliveryFailureAt,id:String(message.id||''),channel:message.channel,reason:safe,stage,text:String(message.text||'').slice(0,300)};
          console.warn(`[AI response debug] FAILED id=${String(message.id||'')} channel=${message.channel} stage=${stage} reason=${safe}`);
          console.warn(`[AI radio worker] delivery failed stage=${stage} reason=${safe}`);
          const failKey=`${message.channel}:${safe}:${stage}`,now=Date.now();
          if(now-(this.deliveryFailureThrottle.get(failKey)||0)>=5000){this.deliveryFailureThrottle.set(failKey,now);try{this.events.add({kind:'delivery_failed',channel:Number(message.channel),reason:safe});}catch{}}
        }
      }
      finally {
        // Hold carrier just long enough after speech to avoid an unnaturally
        // instant synthetic cut-off without adding an artificial squelch sample.
        if(this.connected){await new Promise(r=>setTimeout(r,message.emergency===true?24:28));this.socket.emit('setTalking',{state:false,frequency:message.channel});this.socket.emit('setSpeakerChannel',-1);}
        this.controller=null;this.currentMessage=null;
      }
    }} finally {this.running=false;}
  }
  close(){this.stopped=true;if(this.reconnectTimer)clearTimeout(this.reconnectTimer);this.cancel();this.socket?.disconnect();}
}
