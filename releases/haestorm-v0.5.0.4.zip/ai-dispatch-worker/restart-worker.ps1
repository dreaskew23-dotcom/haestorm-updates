$ErrorActionPreference = 'Stop'
$profile = Import-Clixml -LiteralPath (Join-Path $PSScriptRoot 'worker.secret.xml')
$pointer = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($profile.BridgeToken)
try { $token = [Runtime.InteropServices.Marshal]::PtrToStringBSTR($pointer) }
finally { [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($pointer) }
try {
    try {
        $health = Invoke-RestMethod -Uri 'http://127.0.0.1:8789/health' -Headers @{ Authorization = "Bearer $token" } -TimeoutSec 2
        if ($health.ok -ne $true) { throw 'Unexpected local worker response.' }
        Invoke-RestMethod -Method Post -Uri 'http://127.0.0.1:8789/shutdown' -Headers @{ Authorization = "Bearer $token" } -Body '{}' -ContentType 'application/json' -TimeoutSec 2 | Out-Null
        Start-Sleep -Milliseconds 1000
    } catch {
        if (Get-NetTCPConnection -LocalPort 8789 -State Listen -ErrorAction SilentlyContinue) { throw 'Worker port is occupied or shutdown failed; no second worker was started.' }
    }
    $startupScript = Join-Path $PSScriptRoot 'start-worker.ps1'
    Start-Process -FilePath 'powershell.exe' -ArgumentList @('-NoProfile','-ExecutionPolicy','Bypass','-File',"`"$startupScript`"") -WorkingDirectory $PSScriptRoot -WindowStyle Hidden -RedirectStandardOutput (Join-Path $PSScriptRoot 'worker.log') -RedirectStandardError (Join-Path $PSScriptRoot 'worker-error.log') | Out-Null
    Write-Host 'Worker launched in the background. Check /dispatchspeechhealth after server activation.'
    # HAESTORM v0.5.0.4 startup verification: wait briefly and print the build that actually started.
    $deadline=(Get-Date).AddSeconds(45)
    do {
        Start-Sleep -Milliseconds 750
        try {
            $verify=Invoke-RestMethod -Uri 'http://127.0.0.1:8789/health' -Headers @{ Authorization = "Bearer $token" } -TimeoutSec 2
            if($verify.ok -eq $true){
                Write-Host ("Worker ready: {0}" -f $verify.workerBuild)
                break
            }
        } catch {}
    } while((Get-Date)-lt $deadline)
} finally { $token = $null }
