'use strict';

const net = require('net');
const path = require('path');
const { spawn } = require('child_process');

const RESOURCE = GetCurrentResourceName();
const WORKER_PORT = Number(GetConvar('ai_dispatch_worker_port', '8789')) || 8789;
const CHECK_MS = Math.max(15000, Number(GetConvar('ai_dispatch_worker_watch_ms', '30000')) || 30000);
const STARTUP_SETTLE_MS = Math.max(8000, Number(GetConvar('ai_dispatch_worker_startup_settle_ms', '15000')) || 15000);
const START_TIMEOUT_MS = Math.max(30000, Number(GetConvar('ai_dispatch_worker_start_timeout_ms', '90000')) || 90000);
const RETRY_BACKOFF_MS = Math.max(15000, Number(GetConvar('ai_dispatch_worker_retry_backoff_ms', '30000')) || 30000);

let launchCycle = null;
let lastAttemptAt = 0;
let nextAllowedAttemptAt = 0;
let missingPathWarned = false;
let startupSettling = true;

function workerPath() {
  return String(GetConvar('ai_dispatch_worker_path', '') || '').trim();
}

function isListening(port, timeoutMs = 1200) {
  return new Promise((resolve) => {
    const socket = new net.Socket();
    let done = false;
    const finish = (value) => {
      if (done) return;
      done = true;
      try { socket.destroy(); } catch (_) {}
      resolve(value);
    };
    socket.setTimeout(timeoutMs);
    socket.once('connect', () => finish(true));
    socket.once('timeout', () => finish(false));
    socket.once('error', () => finish(false));
    socket.connect(port, '127.0.0.1');
  });
}

async function waitForWorker(timeoutMs) {
  const deadline = Date.now() + timeoutMs;
  while (Date.now() < deadline) {
    if (await isListening(WORKER_PORT, 1200)) return true;
    await new Promise(r => setTimeout(r, 1500));
  }
  return false;
}

async function launchWorker(reason) {
  if (launchCycle) return launchCycle;
  const now = Date.now();
  if (now < nextAllowedAttemptAt) return false;

  const dir = workerPath();
  if (!dir) {
    if (!missingPathWarned) {
      console.error(`[${RESOURCE}] ai_dispatch_worker_path is not set. Add the worker path to server.cfg.`);
      missingPathWarned = true;
    }
    return false;
  }

  launchCycle = (async () => {
    lastAttemptAt = Date.now();
    nextAllowedAttemptAt = lastAttemptAt + RETRY_BACKOFF_MS;
    const script = path.join(dir, 'restart-worker.ps1');
    console.log(`[${RESOURCE}] Worker offline (${reason}); starting one AI dispatch worker launch cycle...`);

    try {
      const child = spawn('powershell.exe', [
        '-NoProfile',
        '-ExecutionPolicy', 'Bypass',
        '-File', script
      ], {
        cwd: dir,
        windowsHide: true,
        detached: true,
        stdio: 'ignore'
      });

      child.once('error', (err) => {
        console.error(`[${RESOURCE}] Worker launch failed: ${err && err.message ? err.message : err}`);
        console.error(`[${RESOURCE}] Confirm server.cfg contains: add_unsafe_child_process_permission \"${RESOURCE}\"`);
      });
      child.unref();
    } catch (err) {
      console.error(`[${RESOURCE}] Failed to launch worker: ${err && err.message ? err.message : err}`);
      console.error(`[${RESOURCE}] Confirm server.cfg contains: add_unsafe_child_process_permission \"${RESOURCE}\"`);
      return false;
    }

    const up = await waitForWorker(START_TIMEOUT_MS);
    if (up) {
      console.log(`[${RESOURCE}] Worker is online on 127.0.0.1:${WORKER_PORT}; launch cycle complete.`);
      nextAllowedAttemptAt = 0;
      return true;
    }

    console.error(`[${RESOURCE}] Worker did not become ready within ${Math.round(START_TIMEOUT_MS/1000)}s. Next retry is backoff-controlled.`);
    return false;
  })();

  try { return await launchCycle; }
  finally { launchCycle = null; }
}

async function checkWorker(reason) {
  try {
    if (await isListening(WORKER_PORT)) return true;
    if (startupSettling) return false;
    return await launchWorker(reason);
  } catch (err) {
    console.error(`[${RESOURCE}] Worker health check failed: ${err && err.message ? err.message : err}`);
    return false;
  }
}

function scheduleCheck(reason, delayMs) {
  setTimeout(() => {
    checkWorker(reason).catch((err) => {
      console.error(`[${RESOURCE}] Watchdog check failed: ${err && err.message ? err.message : err}`);
    });
  }, delayMs);
}

// Give the normal server/worker startup path time to settle before the watchdog tries to help.
setTimeout(() => {
  startupSettling = false;
  checkWorker('server startup').catch(() => {});
}, STARTUP_SETTLE_MS);

setInterval(() => {
  checkWorker('health watchdog').catch((err) => {
    console.error(`[${RESOURCE}] Watchdog check failed: ${err && err.message ? err.message : err}`);
  });
}, CHECK_MS);

on('onResourceStart', (name) => {
  if (name === 'tRadio' || name === 'haestorm-ai-dispatch') {
    scheduleCheck(`${name} started`, Math.max(3000, STARTUP_SETTLE_MS));
  }
});

console.log(`[${RESOURCE}] v0.5.0.5 active; single-launch watchdog, ${Math.round(STARTUP_SETTLE_MS/1000)}s startup settle, ${Math.round(START_TIMEOUT_MS/1000)}s launch timeout.`);
